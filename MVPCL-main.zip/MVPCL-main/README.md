### This is the offical pytorch implementation of this paper:
#### Multi-View Prototype Consistency Learning for Semi-Supervised Medical Image Segmentation

<p align="center">
    <img src="logs/Fig2_Overall-framework_00.png" alt="Banner" width="800" />
</p>

## Preparation
### Step1: create environment
```shell
conda create -n seg python=3.8
conda activate seg
conda install pytorch==1.12.1 torchvision==0.13.1 torchaudio==0.12.1 cudatoolkit=11.3 -c pytorch
```
### Step2: install package
```shell
pip install -r requirements.txt
```


### Step3: process datasets
Please download and organize the datasets in this structure:

Dataset LiTS: download in [this website](https://www.kaggle.com/datasets/andrewmvd/liver-tumor-segmentation).

Dataset LA: download in [this website](https://www.cardiacatlas.org/atriaseg2018-challenge/atria-seg-data/)

Dataset ACDC: download in [this website](https://aistudio.baidu.com/datasetdetail/136629)

```
MVPCL-master 
├── data
    ├── LiTS
    ├── LA
    ├── ACDC
    
```

### Content Hierarchy
```
root
    ├── checkpoints: weight file.
    ├── data: folders containing data used.
    |    └── LiTS
    |       ├── imagesTr
    |       ├── labelsTr    
    |       └── dataset.json
    ├── results: generated results (images, labels, segmentations, figures, etc.). 
    └── MVPCL-master
          ├── configs: `config_loader.py`.
          ├── logs: training log files and pictures. 
          ├── model: defines network model.   
          ├── utils: evaluation metric. 
          ├── `train.py`: training code.
          ├── `README.md`: help file.
          ├── `requirement.txt`: required packages.
          └── `test.py`: testing code.
```

## Train and Test model
<details>
  <summary><b>Stage 1.</b> Training the model</summary>

#### Step 1: Modify parameters in config_loader: 
--data_path="PATH/TO/YOUR/DATASET", 
--test_ckpt=300, 
--resume_ckpt=0 
#### Step 2: To train a model.
```
## Under MVPCL-master/
python train.py
```
#### Step 3: To test a model (automatically done during `train` mode).
```
# Under MVPCL-master/
python test.py
```
</details>

<details>
  <summary><b>Stage 2.</b> Visualize the segmentation results</summary>

#### Use tensorboard to see loss.
```
(seg) C:MVPCL-master\logs>tensorboard --logdir="log_visual" --port=6004
Open the website to check:
http://localhost:6004/
```

</details>

