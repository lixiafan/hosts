import argparse

def get_config():
    parser = argparse.ArgumentParser(description="Liver Multi-View Segmentation")

    # Path
    # parser.add_argument("--data_path", default="/root/autodl-tmp/data/LiTS-data", type=str, help="The path of dataset")
    # parser.add_argument("--json_path", default="/root/autodl-tmp/data/LiTS-data/dataset.json", type=str, help="The dataset json file")

    # LA
    parser.add_argument("--data_path", default="/root/autodl-tmp/lxf/LA", type=str, help="The path of dataset")
    parser.add_argument("--json_path", default="/root/autodl-tmp/lxf/LA/dataset_16_64.json", type=str, help="The dataset json file")

    # parser.add_argument("--data_path", default="/root/autodl-tmp/lxf/ACDC_nii", type=str, help="The path of dataset")
    # parser.add_argument("--json_path", default="/root/autodl-tmp/lxf/ACDC_nii/dataset_52_208.json", type=str, help="The dataset json file")
    # parser.add_argument("--json_path", default="/root/autodl-tmp/lxf/ACDC_nii/dataset_26_234.json", type=str, help="The dataset json file")

    parser.add_argument("--logdir", default="./logs", type=str, help="The file to save tensorboard logs")
    parser.add_argument("--test_ckpt", type=int, default=240, help="test trained checkpoint")
    parser.add_argument("--result_dir", default='../results', type=str)
    parser.add_argument("--resume_ckpt", type=int, default=0, help="resume training from pretrained checkpoint")

    # Params
    parser.add_argument("--workers", default=4, type=int, help="number of workers")
    parser.add_argument("--batch_size", default=1, type=int, help="number of labeled batch")
    parser.add_argument("--lab_batch_size", default=1, type=int, help="number of labeled batch")
    parser.add_argument("--unlab_batch_size", default=1, type=int, help="number of unlabeled batch")
    parser.add_argument("--current_epoch", default=0, type=int, help="current epoch")
    parser.add_argument("--max_epochs", default=1500, type=int, help="max epoch number")
    parser.add_argument("--optim_lr", default=1e-4, type=float, help="optimization learning rate")
    parser.add_argument("--optim_name", default="adamw", type=str, help="optimization algorithm")
    parser.add_argument("--lrschedule", default="cosine_anneal", type=str, help="type of learning rate scheduler")
    parser.add_argument("--momentum", default=0.99, type=float, help="momentum")
    parser.add_argument("--feature_size", default=24, type=int, help="feature size")  # 48
    parser.add_argument("--in_channels", default=1, type=int, help="number of input channels")
    parser.add_argument("--out_channels", default=2, type=int, help="number of output channels")
    parser.add_argument("--cross_attention_in_origin_view", action="store_true", help="Whether compute cross attention in original view") 
    parser.add_argument("--eval_num", default=20, type=int, help="evaluation frequency")
    parser.add_argument("--infer_overlap", default=0.7, type=float, help="sliding window inference overlap")
    parser.add_argument('--consistency_rampup', type=float, default=300.0, help='consistency_rampup')
    parser.add_argument('--scaler', type=float,  default=1, help='multiplier of prototype')

    parser.add_argument('--ema_decay', type=float,  default=0.99, help='ema_decay')

    # LiTS
    # parser.add_argument("--space_x", default=2, type=float, help="spacing in x direction") 
    # parser.add_argument("--space_y", default=2, type=float, help="spacing in y direction") 
    # parser.add_argument("--space_z", default=1.25, type=float, help="spacing in z direction") 

    # LA
    parser.add_argument("--space_x", default=1.2, type=float, help="spacing in x direction") 
    parser.add_argument("--space_y", default=1.2, type=float, help="spacing in y direction") 
    parser.add_argument("--space_z", default=0.75, type=float, help="spacing in z direction") 

    # ACDC
    # parser.add_argument("--space_x", default=1.2, type=float, help="spacing in x direction") 
    # parser.add_argument("--space_y", default=1.2, type=float, help="spacing in y direction") 
    # parser.add_argument("--space_z", default=0.25, type=float, help="spacing in z direction") 


    parser.add_argument("--a_min", default=0.0, type=float, help="a_min in ScaleIntensityRanged")
    parser.add_argument("--a_max", default=230.0, type=float, help="a_max in ScaleIntensityRanged")
    parser.add_argument("--b_min", default=0.0, type=float, help="b_min in ScaleIntensityRanged")
    parser.add_argument("--b_max", default=1.0, type=float, help="b_max in ScaleIntensityRanged")
    parser.add_argument("--roi_x", default=96, type=int, help="roi size in x direction")
    parser.add_argument("--roi_y", default=96, type=int, help="roi size in y direction")
    parser.add_argument("--roi_z", default=96, type=int, help="roi size in z direction")
    parser.add_argument("--RandFlipd_prob", default=0.5, type=float, help="RandFlipd aug probability")
    parser.add_argument("--RandRotate90d_prob", default=0.25, type=float, help="RandRotate90d aug probability")
    parser.add_argument("--RandScaleIntensityd_prob", default=0.5, type=float, help="RandScaleIntensityd aug probability")
    parser.add_argument("--RandShiftIntensityd_prob", default=0.5, type=float, help="RandShiftIntensityd aug probability")

    return parser
