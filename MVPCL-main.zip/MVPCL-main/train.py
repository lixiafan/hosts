import configs.config_loader as cfg_loader
from model.Trainer import Trainer
from utils.dataset import Med_train, MedCT_val
from utils.dataset import custom_collate_fn
from torch.utils.data import DataLoader

if __name__ == '__main__':
    parser = cfg_loader.get_config()
    args = parser.parse_args()

    # Supervised data read in
    # train_dataset = Med_train(args, split='training')
    # train_loader = DataLoader(dataset=train_dataset, batch_size=args.batch_size, num_workers=args.workers,
    #                           shuffle=False, collate_fn=custom_collate_fn, drop_last=False)


    # Semi-supervised data read in
    train_dataset_lab = Med_train(args, split='lab')
    train_loader_lab = DataLoader(dataset=train_dataset_lab, batch_size=args.lab_batch_size, num_workers=args.workers,
                                  shuffle=False, collate_fn=custom_collate_fn, drop_last=False)

    train_dataset_unlab = Med_train(args, split='unlab')
    train_loader_unlab = DataLoader(dataset=train_dataset_unlab, batch_size=args.unlab_batch_size, num_workers=args.workers,
                                  shuffle=False, collate_fn=custom_collate_fn, drop_last=False)
    
    val_dataset = MedCT_val(args)
    val_loader = DataLoader(dataset=val_dataset, batch_size=args.batch_size, num_workers=args.workers, shuffle=False, drop_last=False)
    
    print("{} iterations for lab per epoch.".format(len(train_dataset_lab)))
    print("{} iterations for unlab per epoch.".format(len(train_dataset_unlab)))
    print("{} iterations for val.".format(len(val_loader)))
    
    trainer = Trainer(args, train_loader_lab=train_loader_lab, train_loader_unlab=train_loader_unlab, val_loader=val_loader)
    trainer.train_model()
