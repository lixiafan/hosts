import numpy as np
import nibabel as nib
import logging
import torch
import os
import sys
import time
from model import MVPCL
from monai.transforms import Spacing
from monai.networks.utils import one_hot
from monai.metrics import compute_hausdorff_distance, compute_average_surface_distance # , compute_meandice
from monai.metrics.meaniou import compute_iou

from utils.inferers import double_sliding_window_inference
from utils.utils import resample_3d, dice #, calculate_metric_percase

class Tester(object):
    def __init__(self, loader, args):
        self.test_loader = loader
        self.args = args
        self.model = MVPCL(args)
        if args.optim_name == "adam":
            self.optimizer = torch.optim.Adam(params=self.model.parameters(), lr=args.optim_lr)
        elif args.optim_name == "adamw":
            self.optimizer = torch.optim.AdamW(params=self.model.parameters(), lr=args.optim_lr)
        elif args.optim_name == "sgd":
            self.optimizer = torch.optim.SGD(params=self.model.parameters(), lr=args.optim_lr, momentum=args.momentum, nesterov=True)
        else:
            raise ValueError("Unsupported Optimization Procedure: " + str(args.optim_name))

        if args.lrschedule == "cosine_anneal":
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=args.max_epochs)
        else:
            self.scheduler = None

        if not os.path.exists(args.logdir):
            os.makedirs(args.logdir, exist_ok=True)

    
        # Log file
        self.data_name = args.data_path.split('/')[-1]
        log_dir = args.logdir + f'/test_log_{self.data_name}.txt'

        if log_dir:
            # set up logger
            logging.basicConfig(filename=log_dir, level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%y-%m-%d %H:%M:%S')
            logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
            logging.info('-------------new start------------')
            logging.info('Testing History')
            logging.info("Dataset: [{}]".format(self.data_name))
            logging.info("Length of test dataset: {}".format(len(self.test_loader)))

    def test(self):
        self.model.cuda()
        self.model.eval()

        
        if self.args.test_ckpt:
            epoch = self.args.test_ckpt
            self.load_checkpoint(epoch, self.data_name)

 

        result_file = self.args.result_dir + f"/results_{self.args.test_ckpt}_{self.data_name}"
        if not os.path.exists(result_file):
            os.makedirs(result_file)

        spacing = Spacing(pixdim=(1, 1, 1), mode="nearest")
        hd_per = 95
        view = ['Cor1', 'Sag2', 'Sag1', 'Axi2', 'Axi1', 'Cor2', 'Fuse']
        dice_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        hd_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        asd_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        iou_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        dice_out_2 = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        pre_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        re_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        acc_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))
        sp_out = np.zeros((len(self.test_loader), len(view), self.args.out_channels - 1))


        with torch.no_grad():
            for id, batch in enumerate(self.test_loader):
                val_inputs, val_labels = batch[0].cuda(), batch[1].cuda() # volume-75.nii, val_inputs.shape = [1, 1, 194, 194, 356], image.shape = (512, 512, 89)
                
                original_affine = batch[2][0].numpy()
                target_affine = batch[3][0].numpy()
                img_name = batch[4][0]
                zooms = batch[5]
                logging.info("Inference on case {}, Ori shape: {}, zooms: {}, Ori direction: {}, Des direction: {}".format(img_name, val_labels.shape, zooms, nib.aff2axcodes(original_affine), nib.aff2axcodes(target_affine)))
                _, _, h, w, d = val_labels.shape
                target_shape = (h, w, d)

                val_labels[val_labels == 2] = 0
                val_labels[val_labels == 3] = 0

                val_labels = val_labels.cpu().numpy()[:, :, :, :, :]
        
                torch.cuda.empty_cache()
                output_list = []
                val_fuse = 0

                val_labels = spacing(val_labels, original_affine)[0]
                val_labels = np.expand_dims(val_labels, axis=0)
                val_labels = one_hot(torch.from_numpy(val_labels), num_classes=self.args.out_channels, dim=1)
                overlap_total = []
                num_spatial_dims = len(val_inputs.shape) - 2
                [overlap_total.append(self.args.infer_overlap) for i in range(num_spatial_dims)]
                for i in range(3):
                    val_outputs_1, val_outputs_2 = double_sliding_window_inference(
                        val_inputs, i, (self.args.roi_x, self.args.roi_y, self.args.roi_z), 8, self.model, overlap=overlap_total,
                        mode="gaussian"
                    )

                    val_outputs_1 = torch.softmax(val_outputs_1, 1).cpu().numpy()[0]
                    val_outputs_2 = torch.softmax(val_outputs_2, 1).cpu().numpy()[0]
                    val_fuse = val_fuse + val_outputs_1 + val_outputs_2
                    output_list.append(val_outputs_1)
                    output_list.append(val_outputs_2)
                output_list.append(val_fuse)

                
                for i, output in enumerate(output_list):
                    output = np.argmax(output, axis=0, keepdims=False) 

                    output = resample_3d(output, target_shape) 


                    target_ornt = nib.orientations.axcodes2ornt(tuple(nib.aff2axcodes(original_affine))) # ori direction (R,A,S)nib.orientations.ornt2axcodes(nib.orientations.io_orientation(original_affine))
                    out_ornt = nib.orientations.axcodes2ornt(tuple(nib.aff2axcodes(target_affine)))
                    ornt_transf = nib.orientations.ornt_transform(out_ornt, target_ornt)
                    
                    output = nib.orientations.apply_orientation(output, ornt_transf)
                    if view[i] == "Fuse":
                        nib.save(nib.Nifti1Image(output.astype(np.uint8), affine=original_affine), # [::-1, ::-1, :]
                             os.path.join(result_file, view[i] + '_' + img_name))
                        logging.info("---View {} result saved in {}.".format(view[i], os.path.join(result_file, view[i] + '_' + img_name)))
                    
                    output = np.expand_dims(spacing(np.expand_dims(output, axis=0), original_affine)[0], axis=0)
                    output = np.expand_dims(one_hot(torch.from_numpy(output), num_classes=self.args.out_channels, dim=0), axis=0)
        

                    time11 = time.time()
                    # dice_ = compute_meandice(output, val_labels, include_background=False).numpy()[0]
                    dice_ = dice(output, np.array(val_labels)) # array, output.shape = (1, 2, 512, 512, 98)
                    hd_ = compute_hausdorff_distance(output, val_labels, percentile=hd_per).numpy()[0][0]
                    asd_ = compute_average_surface_distance(output, val_labels).numpy()[0]
                    iou_ = compute_iou(torch.tensor(output), val_labels) # l

                    # Recall、Precision and Sensitivity
                    tp = np.sum((output == 1) & (np.array(val_labels) == 1)).item()
                    tn = np.sum((output == 0) & (np.array(val_labels) == 0)).item() #
                    fn = np.sum((output == 0) & (np.array(val_labels) == 1)).item()
                    fp = np.sum((output == 1) & (np.array(val_labels) == 0)).item()

                    dice2 = 2 * tp / (fp + 2 * tp + fn)
                    recall = tp / (tp + fn)
                    precision = tp / (tp + fp)
                    accuracy = (tp + tn) / (tp + fp + tn + fn)
                    specificity = tn / (tn + fp)

                    if view[i] == "Fuse":
                        time12 = time.time()
                        logging.info("Inference time: {}".format(time12-time11))

                        logging.info("{} View, Dice: {}".format(view[i], np.mean(dice_)))
                        logging.info("{} View, HD: {}".format(view[i], np.mean(hd_)))
                        logging.info("{} View, ASD: {}".format(view[i], np.mean(asd_)))
                        logging.info("{} View, IoU: {}".format(view[i], torch.mean(iou_)))
                        logging.info("{} View, Dice_2: {}".format(view[i], np.mean(dice2)))
                        logging.info("{} View, Recall: {}".format(view[i], np.mean(recall)))
                        logging.info("{} View, Precision: {}".format(view[i], np.mean(precision)))
                        logging.info("{} View, Accuracy: {}".format(view[i], np.mean(accuracy)))
                        logging.info("{} View, Specificity: {}".format(view[i], np.mean(specificity)))


                    dice_out[id, i, :] = dice_
                    hd_out[id, i, :] = hd_
                    asd_out[id, i, :] = asd_
                    iou_out[id, i, :] = torch.mean(iou_).numpy()
                    dice_out_2[id, i, :] = dice2
                    pre_out[id, i, :] = precision
                    re_out[id, i, :] = recall
                    acc_out[id, i, :] = accuracy
                    sp_out[id:, i, :] = specificity

            for i in range(len(view)):
                logging.info("Overall {} View, Mean Dice: {}".format(view[i], np.mean(dice_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean HD: {}".format(view[i], np.mean(hd_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean ASD: {}".format(view[i], np.mean(asd_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean IoU: {}".format(view[i], np.mean(iou_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean Dice_2: {}".format(view[i], np.mean(dice_out_2[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean Precision: {}".format(view[i], np.mean(pre_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean Recall: {}".format(view[i], np.mean(re_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean Accuracy: {}".format(view[i], np.mean(acc_out[:, i, :], axis=0)))
                logging.info("Overall {} View, Mean Specificity: {}".format(view[i], np.mean(sp_out[:, i, :], axis=0)))
            
        logging.info("Final result saved in {}".format(result_file))


    # Load checkpoint
    def load_checkpoint(self, epoch, data_name):
        checkpoint = torch.load(f'../checkpoints/ckpt_{data_name}_26/epoch_{epoch}_{data_name}.pth')
        self.current_epoch = checkpoint['epoch']
        self.model.load_state_dict(checkpoint['model_state_dict'])
        # self.optimizer.load_state_dict(checkpoint['optimizer'])
        # self.scheduler.load_state_dict(checkpoint['scheduler'])
        logging.info(f"Successfully load checkpoints in epoch_{epoch}_{data_name}.pth")