import os
import sys
import time
import torch
import logging
import numpy as np
import nibabel as nib
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.tensorboard import SummaryWriter
from torchvision.utils import make_grid
from torch.nn.modules.loss import CrossEntropyLoss
from torch.nn import KLDivLoss, CosineEmbeddingLoss
from monai.losses import DiceCELoss
from monai.transforms import Spacing
from monai.networks.utils import one_hot

from model import MVPCL
from utils import view_ops
from utils.utils import AverageMeter
from utils.losses import DiceLoss, FocalLoss, SoftIoULoss, to_one_hot
from utils.Generate_Prototype import getPrototype, calDist
from utils.utils import get_current_consistency_weight, resample_3d, dice
from utils.inferers import double_sliding_window_inference
from utils import statistic
import cv2

import warnings
warnings.filterwarnings("ignore")

class Trainer(object):
    def __init__(self, args, train_loader_lab=None, train_loader_unlab=None, val_loader=None):
        self.args = args

        # DataLoader
        self.train_loader_lab = train_loader_lab
        self.train_loader_unlab = train_loader_unlab
        self.val_loader = val_loader

        # Epoch
        self.current_epoch = args.current_epoch
        self.j = 0 
        self.max_dice = 0 

        # Model
        self.student_model = self.create_model(ema=False)
        self.teacher_model = self.create_model(ema=True)

        # Train: scaler, autocast, optimizer, scheduler
        self.scaler = torch.cuda.amp.GradScaler()
        self.autocast = torch.cuda.amp.autocast
        if args.optim_name == "adam":
            self.optimizer = torch.optim.Adam(params=self.student_model.parameters(), lr=args.optim_lr)
        elif args.optim_name == "adamw":
            self.optimizer = torch.optim.AdamW(params=self.student_model.parameters(), lr=args.optim_lr)
        elif args.optim_name == "sgd":
            self.optimizer = torch.optim.SGD(params=self.student_model.parameters(), lr=args.optim_lr, momentum=args.momentum, nesterov=True)
        else:
            raise ValueError("Unsupported Optimization Procedure: " + str(args.optim_name))
        
        if args.lrschedule == "cosine_anneal":
            self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=args.max_epochs)
        else:
            self.scheduler = None

        # Tensorboard
        if not os.path.exists(args.logdir):
            os.makedirs(args.logdir, exist_ok=True)
        self.writer = SummaryWriter(args.logdir)

        # Log file
        self.data_name = args.data_path.split('/')[-1]
        log_dir = args.logdir + f'/train_log_{self.data_name}_{len(self.train_loader_lab)}.txt'
        if log_dir:
            # set up logger
            logging.basicConfig(filename=log_dir, level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%y-%m-%d %H:%M:%S') 
            logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
            logging.info('-------------new start------------')
            logging.info('Training History')
            logging.info("Dataset: [{}]".format(self.data_name))
            logging.info("Length of labeled train dataset: {}".format(len(self.train_loader_lab)))
            logging.info("Length of unlabeled train dataset: {}".format(len(self.train_loader_unlab)))
            logging.info("Length of val dataset: {}".format(len(self.val_loader)))

        # checkpoints file
        ckpt_file = f'../checkpoints/ckpt_{self.data_name}_{len(self.train_loader_lab)}'
        if not os.path.exists(ckpt_file):
            os.makedirs(ckpt_file)
        
        # if self.current_epoch == 0:
        #     logging.info(self.student_model)

        # Loss
        self.self_crit = DiceCELoss(to_onehot_y=True, softmax=True)
        self.mutual_crit = KLDivLoss(reduction='mean')
        # self.mutual_crit = CosineEmbeddingLoss()
        self.dice_loss = DiceLoss(nclass=args.out_channels)
        self.focal_loss = FocalLoss()
        self.ce_loss = CrossEntropyLoss()
        self.iou_loss = SoftIoULoss(nclass=args.out_channels)
        self.pixel_level_ce_loss = CrossEntropyLoss(reduction='none')
        
    def create_model(self,ema=False):
        net = MVPCL(self.args)
        model = net.cuda()
        if ema:
            for param in model.parameters():
                param.detach_()
        return model
    

    def train_model(self):
        self.student_model.cuda()
        self.student_model.train()

        # resume
        if self.args.resume_ckpt:
            epoch = self.args.resume_ckpt #int(self.args.resume_ckpt.split('_')[1])
            # load checkpoint
            self.load_checkpoint(epoch, self.data_name)
            logging.info('=> resume! load checkpoint epoch{}'.format(epoch))

        logging.info("Start from epoch {}!".format(self.current_epoch))
        for epoch in range(self.current_epoch, self.args.max_epochs + 1):

            self.train_one_epoch(epoch)
            
            # Add Validation
            # if epoch % self.args.eval_num == 0:
            #     val_dice = self.validation(epoch)
            #     if val_dice > self.max_dice:
            #         self.max_dice = val_dice
            #         self.save_checkpoint(epoch, self.data_name)
            #         logging.info("Max dice: {}".format(self.max_dice))


            if epoch % self.args.eval_num == 0:
                self.save_checkpoint(epoch, self.data_name)



    def train_one_epoch(self, epoch):
        run_loss = AverageMeter()
        run_self_loss = AverageMeter()
        run_mutual_loss = AverageMeter()
        run_focal_loss = AverageMeter()
        run_iou_loss = AverageMeter()
        run_sup_loss = AverageMeter()
        run_unsup_loss = AverageMeter()

        run_lab_pc_loss = AverageMeter()
        run_unlab_pc_loss = AverageMeter()

        start_time = time.time()

        for param in self.student_model.parameters():
            param.grad = None

        for idx, (batch_data_lab, batch_data_unlab) in enumerate(zip(self.train_loader_lab, self.train_loader_unlab)):
            self.optimizer.zero_grad()

            # Labeled data
            data_lab, target_lab, img_name_lab = batch_data_lab[0].cuda(), batch_data_lab[1].cuda(), batch_data_lab[2]

            
            # Deal label
            if self.data_name == 'LA':
                target_lab[target_lab == 255] = 1
            elif self.data_name == 'LiTS_data' or 'LiTS-data':
                target_lab[target_lab == 2] = 0 

            lab_lab_onehot = to_one_hot(target_lab, self.args.out_channels) # lab_lab_onehot.shape = [2, 2, 96, 96, 96]
            data_list_lab, view_list_lab = view_ops.permute_rand(data_lab)  # data_list_lab[0].shape = [2, 1, 96, 96, 96]

            # Unlabeled data
            data_unlab, img_name_unlab = batch_data_unlab[0].cuda(), batch_data_unlab[2]
            data_list_unlab, view_list_unlab = view_ops.permute_rand(data_unlab)

            
            loss_sup = 0
            loss_unsup = 0
            loss = 0
            self_loss_list = []
            mutual_loss_list = []
            focal_loss_list = []
            iou_loss_list = []
            sup_loss_list = []
            unsup_loss_list = []

            lab_pc_loss_list = []
            unlab_pc_loss_list = []

            # Start train
            with self.autocast():
                '''Supervised'''
                output1, output2, feature_lab1, feature_lab2 = self.student_model(data_list_lab[0], data_list_lab[1], view_list_lab) # two view inputs
                out_list = [output1, output2]
                out_list = view_ops.permute_inverse(out_list, view_list_lab)

                # result of two view
                for i in range(len(out_list)):
                    self_loss = self.self_crit(out_list[i], target_lab) # DiceCELoss
                    focal_loss = self.focal_loss(out_list[i], target_lab) # FocalLoss
                    iou_loss = self.iou_loss(out_list[i], target_lab) # IoULoss
                    mutual_loss = 0
                    for j in range(len(out_list)):  # KL divergence
                        if i != j:
                            mutual_end = self.mutual_crit(F.log_softmax(out_list[i], dim=1), F.softmax(out_list[j], dim=1)) 
                            mutual_loss += mutual_end

                    self_loss_list.append(self_loss.item())
                    mutual_loss_list.append(mutual_loss.item())
                    focal_loss_list.append(focal_loss.item())
                    iou_loss_list.append(iou_loss.item())
                    
                    # Supervised losses
                    loss_sup += (self_loss + focal_loss + iou_loss + mutual_loss / (len(out_list) - 1)) / len(out_list)
                    sup_loss_list.append(loss_sup)

                    # view1: prototype of labeled data 
                    lab_fts = F.interpolate(feature_lab1, size=target_lab.shape[-3:], mode='trilinear') # feature_lab1.shape=(2,96,12,12,12), size=[96, 96, 96], lab_fts.shape=(2,96,96,96,96)
                    lab_prototypes = getPrototype(lab_fts, lab_lab_onehot) # list, length=2 [tensor[1, 96], tensor[1, 96]]

                    # view2: prototype of labeled data 
                    lab_fts2 = F.interpolate(feature_lab2, size=target_lab.shape[-3:], mode='trilinear')
                    lab_prototypes2 = getPrototype(lab_fts2, lab_lab_onehot)


                    '''Unsupervised'''
                    with torch.no_grad():
                        ema_output1, ema_output2, feature_unlab1, feature_unlab2 = self.teacher_model(data_list_unlab[0], data_list_unlab[1], view_list_unlab)
                        
                        # input of uncertainty assessment
                        ema_pred = (ema_output1.detach().to(dtype=torch.float32) + ema_output2.detach().to(dtype=torch.float32)) / 2
                        ema_out_soft = torch.softmax(ema_pred, dim=1) # softmax in channel dim
                        ema_mask = torch.argmax(ema_out_soft, dim=1)
                        ema_mask_onehot = to_one_hot(ema_mask.unsqueeze(1), self.args.out_channels) # ema_mask.unsqueeze(1).shape=(2,1,96,96,96), ema_mask_onehot.shape=(2,2,96,96,96)

                        # uncertainty assessment
                        uncertainty  = -torch.sum(ema_out_soft * torch.log(ema_out_soft + 1e-16), dim=1) # uncertainty.shape = (2, 96, 96, 96)
                        norm_uncertainty = torch.stack([uncertain / torch.sum(uncertain) for uncertain in uncertainty], dim=0)

                        reliability_map = (1 - norm_uncertainty) / np.prod(np.array(norm_uncertainty.shape[-3:])) # reliability_map.shape = (2, 96, 96, 96)

                        # view1: prototype of unlabeled data
                        unlab_ema_fts = F.interpolate(feature_unlab1.detach().to(dtype=torch.float32), size=tuple(ema_mask.shape[-3:]), mode='trilinear') # unlab_ema_fts.shape=(2, 96, 96, 96, 96)
                        unlab_prototypes = getPrototype(unlab_ema_fts, ema_mask_onehot, reliability_map) # list, length=2, [tensor[1,96], tensor[1,96]]

                        # view2: prototype of unlabeled data
                        unlab_ema_fts2 = F.interpolate(feature_unlab2.detach().to(dtype=torch.float32), size=tuple(ema_mask.shape[-3:]), mode='trilinear')
                        unlab_prototypes2 = getPrototype(unlab_ema_fts2, ema_mask_onehot, reliability_map)

                        consistency_weight = get_current_consistency_weight(epoch, self.args.consistency_rampup)


                    '''Prototype fusion'''
                    # some prototypes 
                    prototypes = [((lab_prototypes[c].detach().to(dtype=torch.float32) + lab_prototypes2[c].detach().to(dtype=torch.float32)) / 2 + consistency_weight * (unlab_prototypes[c].detach().to(dtype=torch.float32) + unlab_prototypes2[c].detach().to(dtype=torch.float32)) / 2) / (1 + consistency_weight) for c in range(self.args.out_channels)] # list, length=2, [tensor[1, 96], tensor[1, 96]]

                    lab_dist = torch.stack([calDist(lab_fts.detach().to(dtype=torch.float32), prototype, scaler=self.args.scaler) for prototype in prototypes], dim=1)
                    unlab_dist = torch.stack([calDist(unlab_ema_fts, prototype, scaler=self.args.scaler) for prototype in prototypes], dim=1)

                    '''Prototype consistency learning'''
                    loss_pc_lab = self.ce_loss(lab_dist, target_lab.squeeze(1).to(torch.long).detach()) # lab_dist.shape=(2,2,96,96,96), target_lab.shape=(2,1,96,96,96)
                    loss_pc_unlab = torch.sum(self.pixel_level_ce_loss(unlab_dist, ema_mask) * reliability_map)
                    
                    lab_pc_loss_list.append(loss_pc_lab)
                    unlab_pc_loss_list.append(loss_pc_unlab)

                    loss_unsup = loss_pc_lab + consistency_weight * loss_pc_unlab
                    unsup_loss_list.append(loss_unsup)

                    '''Total loss'''
                    loss = loss_sup + loss_unsup


                self_loss = torch.mean(torch.tensor(self_loss_list)).cuda()
                mutual_loss = torch.mean(torch.tensor(mutual_loss_list)).cuda()
                focal_loss = torch.mean(torch.tensor(focal_loss_list)).cuda()
                iou_loss = torch.mean(torch.tensor(iou_loss_list)).cuda()
                sup_loss = torch.mean(torch.tensor(sup_loss_list)).cuda()

                lab_pc_loss = torch.mean(torch.tensor(lab_pc_loss_list)).cuda()
                unlab_pc_loss = torch.mean(torch.tensor(unlab_pc_loss_list)).cuda()
                unsup_loss = torch.mean(torch.tensor(unsup_loss_list)).cuda()

            self.scaler.scale(loss).backward()
            self.scaler.step(self.optimizer)
            self.scaler.update()

            update_ema_variables(self.student_model, self.teacher_model, self.args.ema_decay, idx)

            run_loss.update(loss.item(), n=self.args.lab_batch_size)
            run_self_loss.update(self_loss.item(), n=self.args.lab_batch_size)
            run_mutual_loss.update(mutual_loss.item(), n=self.args.lab_batch_size)
            run_focal_loss.update(focal_loss.item(), n=self.args.lab_batch_size)
            run_iou_loss.update(iou_loss.item(), n=self.args.lab_batch_size)
            run_sup_loss.update(sup_loss.item(), n=self.args.lab_batch_size)
            run_unsup_loss.update(unsup_loss.item(), n=self.args.unlab_batch_size)

            run_lab_pc_loss.update(lab_pc_loss.item(), n=self.args.lab_batch_size)
            run_unlab_pc_loss.update(unlab_pc_loss.item(), n=self.args.unlab_batch_size)

            logging.info("Epoch: {}/{} Step_lab: {}/{} Data: lab {}, unlab {} loss: {:.4f} self_loss: {:.4f} mutual_loss: {:.4f} focal_loss: {:.4f} iou_loss: {:.4f} lab_pc_loss: {:.4f} unlab_pc_loss: {:.4f} time: {:.2f}"
                  .format(epoch, self.args.max_epochs, idx+1, len(self.train_loader_lab), img_name_lab, img_name_unlab, run_loss.avg, run_self_loss.avg, run_mutual_loss.avg, run_focal_loss.avg, run_iou_loss.avg, run_lab_pc_loss.avg, run_unlab_pc_loss.avg, time.time()-start_time))
            

            self.writer.add_scalar('total_loss/losses', run_loss.avg, epoch)
            self.writer.add_scalar('self_loss/losses', run_self_loss.avg, epoch)
            self.writer.add_scalar('mutual_loss/losses', run_mutual_loss.avg, epoch)
            self.writer.add_scalar('focal_loss/losses', run_focal_loss.avg, epoch)
            self.writer.add_scalar('iou_loss/losses', run_iou_loss.avg, epoch)
            self.writer.add_scalar('sup_loss/losses', run_sup_loss.avg, epoch)
            self.writer.add_scalar('unsup_loss/losses', run_unsup_loss.avg, epoch)
            self.writer.add_scalar('info/consistency_weight', consistency_weight, epoch)
            self.writer.add_scalar('lab_pc_loss/losses', run_lab_pc_loss.avg, epoch)
            self.writer.add_scalar('unlab_pc_loss/losses', run_unlab_pc_loss.avg, epoch)
        
            if epoch % 20 == 0 and (idx == 5 or idx == 10 or idx == 15 or idx == 20):
                image = data_lab[0, 0:1, :, :, 20:61:10].permute(3, 0, 1, 2).repeat(1, 3, 1, 1)
                grid_image = make_grid(image, 5, normalize=True)
                self.writer.add_image('train/Label_image', grid_image, epoch)

                label = target_lab[0, 0:1, :, :, 20:61:10].permute(3, 0, 1, 2).repeat(1, 3, 1, 1)
                grid_mask = make_grid(label, 5, normalize=True)
                self.writer.add_image('train/Ground_truth', grid_mask, epoch)

                output = output1[0, 0:1, :, :, 20:61:10].permute(3, 0, 1, 2).repeat(1, 3, 1, 1)

                uncertainty = uncertainty[0, :, :, 20:61:10].unsqueeze(0).permute(3, 0, 1, 2).repeat(1, 3, 1, 1)
                grid_uncertainty = make_grid(uncertainty, 5, normalize=True)
                self.writer.add_image('train/Uncertainty', grid_uncertainty, epoch)

                nor_uncertainty = norm_uncertainty[0, :, :, 20:61:10].unsqueeze(0).permute(3, 0, 1, 2).repeat(1, 3, 1, 1)
                grid_nor_uncertainty = make_grid(nor_uncertainty, 5, normalize=True)
                self.writer.add_image('train/Norm_Uncertainty', grid_nor_uncertainty, epoch)
                

                map = reliability_map[0, :, :, 20:61:10].unsqueeze(0).permute(3, 0, 1, 2).repeat(1, 3, 1, 1)
                grid = make_grid(map, 5, normalize=True)
                self.writer.add_image('train/reliability_map', grid, epoch)


                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), label[0,:,:,:].permute(1,2,0).cpu(), idx, "label")
                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), label[0,:,:,:].permute(1,2,0).cpu(), idx, "label_heat")
                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), output[0,:,:,:].permute(1,2,0).detach().cpu().numpy(), idx, "pred")
                
                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), uncertainty[0,:,:,:].permute(1,2,0).cpu(), idx, "uncertainty")
                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), nor_uncertainty[0,:,:,:].permute(1,2,0).cpu(), idx, "norm_uncertainty")
                self.show_cam_on_image(image[0,:,:,:].permute(1,2,0).cpu(), map[0,:,:,:].permute(1,2,0).cpu(), idx, "reliablity")

                # mask = ema_mask[0, :, :, 20:61:10].permute(2, 0, 1).long()
                # grid_mask = make_grid(mask.unsqueeze(1), 5, normalize=True)
                # self.writer.add_image('train/EMA_Mask', grid_mask, epoch)

        return None

   # Load checkpoint
    def load_checkpoint(self, epoch, data_name):
        checkpoint = torch.load(f'../checkpoints/ckpt_{data_name}_{len(self.train_loader_lab)}/epoch_{epoch}_{data_name}.pth')
        self.current_epoch = checkpoint['epoch']
        self.student_model.load_state_dict(checkpoint['model_state_dict'])
        # self.optimizer.load_state_dict(checkpoint['optimizer'])
        # self.scheduler.load_state_dict(checkpoint['scheduler'])
        logging.info(f"Successfully load checkpoints in epoch_{epoch}_{data_name}_{len(self.train_loader_lab)}.pth")

    # Save model
    def save_checkpoint(self, epoch, data_name):
        try:
            os.remove(os.path.join(f'../checkpoints/ckpt_{self.data_name}_{len(self.train_loader_lab)}/epoch_{self.j}_{data_name}.pth'))
        except:
            pass
        self.j = epoch

        torch.save({
            'epoch': epoch,
            # 'optimizer': self.optimizer.state_dict(),
            # 'scheduler': self.scheduler.state_dict(),
            'model_state_dict': self.student_model.state_dict(),
        }, f'../checkpoints/ckpt_{self.data_name}_{len(self.train_loader_lab)}/epoch_{epoch}_{data_name}.pth') 
        logging.info(f"Saved model in ../checkpoints/ckpt_{self.data_name}_{len(self.train_loader_lab)}/epoch_{epoch}_{data_name}.pth")


    def validation(self, epoch):
        logging.info("Begin  to vlaidate in epoch [{}]".format(epoch))
        self.student_model.eval()
        self.student_model.cuda()

        spacing = Spacing(pixdim=(1, 1, 1), mode="nearest")
        view = ['Cor1', 'Sag2', 'Sag1', 'Axi2', 'Axi1', 'Cor2', 'Fuse']
        dice_out = np.zeros((len(self.val_loader), len(view), self.args.out_channels - 1))

        with torch.no_grad():
            for id, batch in enumerate(self.val_loader):
                val_inputs, val_labels = batch[0].cuda(), batch[1].cuda() # volume-75.nii, val_inputs.shape = [1, 1, 194, 194, 356], image.shape = (512, 512, 89)
                
                original_affine = batch[2][0].numpy()
                target_affine = batch[3][0].numpy()
                img_name = batch[4][0]
                zooms = batch[5]
                logging.info("Inference on case {}, Ori shape: {}, zooms: {}, Ori direction: {}, Des direction: {}".format(img_name, val_labels.shape, zooms, nib.aff2axcodes(original_affine), nib.aff2axcodes(target_affine)))
                _, _, h, w, d = val_labels.shape
                target_shape = (h, w, d)

                val_labels[val_labels == 2] = 0
                val_labels[val_labels == 3] = 0

                val_labels = val_labels.cpu().numpy()[:, :, :, :, :]
        
                torch.cuda.empty_cache()
                output_list = []
                val_fuse = 0

                val_labels = spacing(val_labels, original_affine)[0]
                val_labels = np.expand_dims(val_labels, axis=0)
                val_labels = one_hot(torch.from_numpy(val_labels), num_classes=self.args.out_channels, dim=1)
                overlap_total = []
                num_spatial_dims = len(val_inputs.shape) - 2
                [overlap_total.append(self.args.infer_overlap) for i in range(num_spatial_dims)]
                for i in range(3):
                    val_outputs_1, val_outputs_2 = double_sliding_window_inference(
                        val_inputs, i, (self.args.roi_x, self.args.roi_y, self.args.roi_z), 8, self.student_model, overlap=overlap_total,
                        mode="gaussian"
                    )

                    val_outputs_1 = torch.softmax(val_outputs_1, 1).cpu().numpy()[0]
                    val_outputs_2 = torch.softmax(val_outputs_2, 1).cpu().numpy()[0]
                    val_fuse = val_fuse + val_outputs_1 + val_outputs_2
                    output_list.append(val_outputs_1)
                    output_list.append(val_outputs_2)
                output_list.append(val_fuse)

                
                for i, output in enumerate(output_list):
                    output = np.argmax(output, axis=0, keepdims=False) 

                    output = resample_3d(output, target_shape) 


                    target_ornt = nib.orientations.axcodes2ornt(tuple(nib.aff2axcodes(original_affine))) # ori direction (R,A,S)nib.orientations.ornt2axcodes(nib.orientations.io_orientation(original_affine))
                    out_ornt = nib.orientations.axcodes2ornt(tuple(nib.aff2axcodes(target_affine)))
                    ornt_transf = nib.orientations.ornt_transform(out_ornt, target_ornt)
                    
                    output = nib.orientations.apply_orientation(output, ornt_transf)
                    
                    output = np.expand_dims(spacing(np.expand_dims(output, axis=0), original_affine)[0], axis=0)
                    output = np.expand_dims(one_hot(torch.from_numpy(output), num_classes=self.args.out_channels, dim=0), axis=0)
        
                    # dice_ = compute_meandice(output, val_labels, include_background=False).numpy()[0]
                    dice_ = dice(output, np.array(val_labels)) # array, output.shape = (1, 2, 512, 512, 98)

                    if view[i] == "Fuse":
                        logging.info("{} View, Dice: {}".format(view[i], np.mean(dice_)))

                    dice_out[id, i, :] = dice_
            
            logging.info("Overall {} View Mean Dice: {}".format(view[6], np.mean(dice_out[:, 6, :], axis=0)))
        return np.mean(dice_out[:, 6, :], axis=0)[0]  

    def show_cam_on_image(self, img, mask, id, name):
        save_path = "./cam_image_{}".format(len(self.train_loader_lab))
        if not os.path.exists(save_path):
            os.makedirs(save_path, exist_ok=True)

        if name == "label":
            cv2.imwrite("./cam_image_{}/image_{}_{}.jpg".format(len(self.train_loader_lab), id, name), np.float32(img) * 255)
            cv2.imwrite("./cam_image_{}/label_{}_{}.jpg".format(len(self.train_loader_lab), id, name), np.uint8(255 * mask))
            
            heatmap = cv2.applyColorMap(np.uint8(255*mask), cv2.COLORMAP_JET)
            heatmap = np.float32(heatmap) / 255
            cam = heatmap + np.float32(img)
            cam = cam / np.max(cam)
            cv2.imwrite("./cam_image_{}/cam_{}_{}.jpg".format(len(self.train_loader_lab), id, name), np.uint8(255 * cam))

        if name == "pred":
            cv2.imwrite("./cam_image_{}/pred_{}_{}.jpg".format(len(self.train_loader_lab), id, name), np.uint8(255 * mask))

        else:
            heatmap = cv2.applyColorMap(np.uint8(255*mask), cv2.COLORMAP_JET)
            heatmap = np.float32(heatmap) / 255
            cam = heatmap + np.float32(img)
            cam = cam / np.max(cam)
            cv2.imwrite("./cam_image_{}/cam_{}_{}.jpg".format(len(self.train_loader_lab), id, name), np.uint8(255 * cam))     


def update_ema_variables(model, ema_model, alpha, global_step):
    # Use the true average until the exponential average is more correct
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param in zip(ema_model.parameters(), model.parameters()):
        ema_param.data.mul_(alpha).add_(1 - alpha, param.data)

