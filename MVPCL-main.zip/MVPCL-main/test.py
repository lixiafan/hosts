import configs.config_loader as cfg_loader
from model.Tester import Tester

from utils.dataset import MedCT_test
from torch.utils.data import DataLoader

import warnings
warnings.filterwarnings("ignore")

if __name__ == '__main__':
    parser = cfg_loader.get_config()
    args = parser.parse_args()

    test_dataset = MedCT_test(args)

    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        sampler=None,
        pin_memory=False,
        # persistent_workers=True,
    )
    print("{} iterations for test.".format(len(test_loader)))
    tester = Tester(loader=test_loader, args=args)

    print("Test 3d model!")
    tester.test()
